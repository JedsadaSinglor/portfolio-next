from multiprocessing.dummy import Lock
from tkinter import *
from tkinter import ttk
import sqlite3
from turtle import st
from PIL import Image,ImageTk
from tkinter import messagebox
from sqlite3 import Error
import random
#color 
black = '#171717'
grey = '#444444'
white = '#EDEDED'
red   = '#FF0000'

def mainWindows() :
    root = Tk()
    root.title('MAIN WINDOWS')
    w = 1280
    h = 720
    x = root.winfo_screenwidth()/2 - w/2
    y = root.winfo_screenheight()/2 - h/2
    root.geometry("%dx%d+%d+%d"%(w,h,x,y))
    root.config(bg='#28b5b5')
    root.option_add('*font',"tahoma 24 bold")
    root.resizable(False, False)
    root.rowconfigure((1,2,3),weight=1)
    root.columnconfigure((0,1,2,3),weight=1)
    return root

def createconnection() :
    global conn,cursor
    conn = sqlite3.connect('Database\DATA.db')
    cursor = conn.cursor()
    return(conn,cursor)

def loginLayout():
    global userentry,pwdentry,loginframe
    regisframe.destroy()
    loginframe = Frame(root)
    loginframe.columnconfigure((0,1),weight=1)
    Label(loginframe,image=logopic).grid(row=0,columnspan=4,pady=50)
    
    Label(loginframe,text="Username : ").grid(row=1,column=0,sticky=E,pady=10)
    userentry = Entry(loginframe,width=30)
    userentry.grid(row=1,column=1,sticky=W)
    Label(loginframe,text="Password  : ").grid(row=2,column=0,sticky=E,pady=10)
    pwdentry = Entry(loginframe,width=30,show='*')
    pwdentry.grid(row=2,column=1,sticky=W)

    Button(loginframe,text="Login",width=20,bg=red,fg=black,command=(lambda:loginclick(userentry.get(),pwdentry.get()))).grid(row=3,columnspan=4,pady=10)
    Button(loginframe,text="Register",width=20,bg=black,fg=red,command=regiswindow).grid(row=4,columnspan=4,pady=10)
    loginframe.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

def loginclick(user,pwd) :
    global result
    if user == "" :
        messagebox.showwarning("Admin:","Pleas enter username")
        userentry.focus_force()
    else :
        sql = "select * from login where user=?"
        cursor.execute(sql,[user])
        result = cursor.fetchall()
        if result :
            if pwd == "" :
                messagebox.showwarning("Admin:","Please enter password")
                pwdentry.focus_force()
            else :
                sql = "select * from login where user=? and pwd=? "
                cursor.execute(sql,[user,pwd])
                result = cursor.fetchone()
                if result :
                    messagebox.showinfo("Admin:","Login By : "+ user)
                    loginframe.destroy()
                    ranMovie()
                else :
                    messagebox.showwarning("Admin:","Incorrect Password!!!!")
                    pwdentry.select_range(0,END)
                    pwdentry.focus_force()
        else :
            messagebox.showerror("Admin:","Username not found\n Please Register before Login!!!!")
            userentry.focus_force()    

def regiswindow() :
    global fullname,lastname,newuser,newpwd,cfpwd,regisframe
    loginframe.destroy()
    regisframe = Frame(root)
    regisframe.rowconfigure((0,1,2,3,4,5,6,7),weight=1)
    regisframe.columnconfigure((0,1),weight=1)
    Label(regisframe,text="Registration",font="Tahoma 26 bold",compound=TOP,bg=grey,fg=red).grid(row=0,column=0,columnspan=2,sticky='news',pady=10)
    Label(regisframe,text='Firstname : ').grid(row=1,column=0,sticky=E,padx=10)
    fullname = Entry(regisframe,width=30)
    fullname.grid(row=1,column=1,sticky='w',padx=10)
    Label(regisframe,text='Lastname : ').grid(row=2,column=0,sticky=E,padx=10)
    lastname = Entry(regisframe,width=30)
    lastname.grid(row=2,column=1,sticky='w',padx=10)
    Label(regisframe,text='Username : ').grid(row=3,column=0,sticky=E,padx=10)
    newuser = Entry(regisframe,width=30)
    newuser.grid(row=3,column=1,sticky='w',padx=10)
    Label(regisframe,text='Password : ').grid(row=4,column=0,sticky=E,padx=10)
    newpwd = Entry(regisframe,width=30,show='*')
    newpwd.grid(row=4,column=1,sticky='w',padx=10)
    Label(regisframe,text='Confirm Password : ').grid(row=5,column=0,sticky=E,padx=10)
    cfpwd = Entry(regisframe,width=30,show='*')
    cfpwd.grid(row=5,column=1,sticky='w',padx=10)
    regisaction = Button(regisframe,text="Submit",command=registration,width=20,bg=red,fg=black)
    regisaction.grid(row=6,columnspan=4)
    fullname.focus_force()
    loginbtn = Button(regisframe,text="Back to Login",command=loginLayout,width=20,bg=black,fg=red)
    loginbtn.grid(row=7,columnspan=4)
    regisframe.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

def registration() : 
    if fullname.get() == "" :
        messagebox.showwarning("Admin: ","Please enter firstname")
        fullname.focus_force()
    elif lastname.get() == "" :
        messagebox.showwarning("Admin: ","Pleasse enter lastname")
        lastname.focus_force()
    elif newuser.get() == "" :
        messagebox.showwarning("Admin: ","Please enter a new username")
        newuser.focus_force()
    elif newpwd.get() == "" :
        messagebox.showwarning("Admin: ","Please enter a password")
        newpwd.focus_force()
    elif cfpwd.get() == "" :
        messagebox.showwarning("Admin: ","Please enter a confirm password")
        cfpwd.focus_force()
    else :
        sql = "select * from login where user=?"
        cursor.execute(sql,[newuser.get()])
        result = cursor.fetchall()
        if result :
            messagebox.showerror("Admin:","The username is already exists")
            newuser.select_range(0,END)
            newuser.focus_force()
        else :
            if newpwd.get() == cfpwd.get() :
                sql = "insert into login values (?,?,?,?)"
                param = [newuser.get(),newpwd.get(),fullname.get(),lastname.get()]
                cursor.execute(sql,param)
                conn.commit()
                #retrivedata()
                messagebox.showinfo("Admin:","Registration Successfully")
                newuser.delete(0,END)
                newpwd.delete(0,END)
                cfpwd.delete(0,END)
                fullname.delete(0,END)
                lastname.delete(0,END)
            else :
                messagebox.showwarning("Admin: ","Incorrect a confirm password\n Try again")
                cfpwd.selection_range(0,END)
                cfpwd.focus_force()

def retrivedata() :
    sql = "select * from login"
    cursor.execute(sql)
    result = cursor.fetchall()
    print("Total row = ",len(result))
    for i,data in enumerate(result) :
        print("Row#",i+1,data)

def initLayout(root):
    fm_header = Frame(root)
    fm_header.columnconfigure((0,1,2,3),weight=1)
    fm_header.rowconfigure((0),weight=1)
    fm_header.grid(row=0,column=0,columnspan=4,sticky='news')
    fm_main = Frame(root)
    fm_main.columnconfigure((0,1,2,3),weight=1)
    fm_main.rowconfigure((0,1,2,3),weight=1)
    fm_main.grid(row=1, column=0,columnspan=4,rowspan=4,sticky='news')
    return fm_header, fm_main

def ranMovie():
    Button(fm_header,text='ภาพยนตร์',bg=red,fg=black,command=ranMovie,bd=0).grid(row=0,column=0,sticky='news')
    Button(fm_header,text='รีวิวภาพยนตร์',bg=grey,fg='white',command=reviewMovie,bd=0).grid(row=0,column=1,sticky='news')
    Button(fm_header,text='รายชื่อภาพยนตร์',bg=grey,fg='white',command=movieList,bd=0).grid(row=0,column=2,sticky='news')
    Button(fm_header,text='รับชมภายหลัง',bg=grey,fg='white',command=profile,bd=0).grid(row=0,column=3,sticky='news')
    rmv_fm = Frame(fm_main)
    rmv_fm.columnconfigure((0,1,2,3),weight=1)
    rmv_fm.rowconfigure((0,1,2,3,4),weight=1)
    rMf = Frame(rmv_fm)
    rMf.grid(row=0,column=0,columnspan=4)
    Label(rMf,text='ภาพยนตร์แนะนำ').grid(row=0,columnspan=4,sticky=N)
    cursor.execute("select * from Movie order by Good desc")
    data = cursor.fetchall()

    for i,row in enumerate(data[0:3]):
        img = Image.open(f"Image\{row[0]}.png").resize((200, 200), Image.ANTIALIAS)#Image\2.jpg
        python_image = ImageTk.PhotoImage(img)
        but_img = Button(rMf,fg=grey,font=('tahoma 20 bold'),image=python_image,command=lambda i=i :function(i))
        but_img.image = python_image 
        but_img.grid(row=1,column=i,sticky=S)
        
    def function(number):
        print(number, 'clicked')
        cursor.execute("select * from Movie order by Good desc")
        data = cursor.fetchall()
        for i,row in enumerate(data[0:3]):
            if number == i:
                    ndata = data[i]
                    showMovie('name',ndata[1])
    Button(rmv_fm,text='สุ่ม',bg=grey,fg=red,width=30,command=ranNum).grid(row=1,column=0,columnspan=4,sticky=S)

    selected_type = StringVar()
    cbx_type = ttk.Combobox(rmv_fm,state='readonly',width=15,textvariable=selected_type)
    cbx_type['values'] =['Action','Adventure','War','Drama','Sci-Fi','Biography','Horror','Romantic','Retro','Thriller','Crime','Fantasy']
    cbx_type.grid(row=2,column=1,pady=10)
    cbx_type.set('ประเภท')
    def typeSec(event):
        sql = 'SELECT * FROM Movie WHERE Type = ?'
        cursor.execute(sql, [selected_type.get()])
        movie = cursor.fetchall()
        for line,row in enumerate(movie):
            if movie == None:
                messagebox.showwarning("Admin: ","Not Found!!")
            else:
                showMovie('type',selected_type.get())

    cbx_type.bind('<<ComboboxSelected>>', typeSec)

    selected_lang = StringVar()
    cbx_lang = ttk.Combobox(rmv_fm,state='readonly',width=15,textvariable=selected_lang)
    cbx_lang['values'] = ['English','Korea','Japan','China','Thailand']
    cbx_lang.grid(row=2,column=2,pady=10)
    cbx_lang.set('ภาษา')
    def langSec(event):
        sql = 'SELECT * FROM Movie WHERE Language = ?'
        cursor.execute(sql, [selected_lang.get()])
        movie = cursor.fetchall()
        for line,row in enumerate(movie):
            if movie == None:
                messagebox.showwarning("Admin: ",selected_lang,"Not Found!!")
            else:
                showMovie('language',selected_lang.get())
    cbx_lang.bind('<<ComboboxSelected>>', langSec)

    Label(rmv_fm,text='ช่องค้นหา',font=('tahoma 20'),bg=grey,fg='white').grid(row=3,column=0,ipadx=100,ipady=5,sticky='sew')
    my_entry = Entry(rmv_fm,width=30,bd=3)
    my_entry.grid(row=3,column=1,columnspan=2,sticky='ew')
    Button(rmv_fm, text='Search', font=('tahoma 18'), bg=grey,fg='white',width=20,command=lambda:search(my_entry.get())).grid(row=3,column=3,sticky='sew')

    name = []
    cursor.execute('SELECT Number,Name FROM Movie')
    movie_name = cursor.fetchall()
    for i,item in enumerate(movie_name):
        name.append(item[1])
    def update(data):
        my_list.delete(0, END)
        for item in data:
            my_list.insert(END, item)
    def fillout(e):
        my_entry.delete(0, END)
        my_entry.insert(0, my_list.get(ANCHOR))
    def check(e):
        typed = my_entry.get()
        
        if typed == '':
            data = name
        else :
            data = []
            for item in name:
                if typed.lower() in item.lower():
                    data.append(item)

        update(data)	
    my_list = Listbox(rmv_fm, width=20,height=5)
    my_list.grid(row=4,column=1,columnspan=2,sticky='ew')
    
    update(name)
    
    
    my_list.bind("<<ListboxSelect>>", fillout )

    my_entry.bind("<KeyRelease>", check)
    



    rmv_fm.grid(row=0,column=0,columnspan=4,rowspan=5,sticky='news')

def ranNum():
    num = random.randint(1,7)
    sql = 'SELECT * FROM Movie WHERE Number = ?'
    cursor.execute(sql, [num])
    movie = cursor.fetchone()
    if movie != None :
        sh_fm = Frame(fm_main)
        sh_fm.rowconfigure((0,1,2,3),weight=1)
        sh_fm.columnconfigure((0,1,2,3),weight=1)
        img = Image.open(f"Image\{movie[0]}.png").resize((500, 500), Image.ANTIALIAS)#Image\2.jpg
        python_image = ImageTk.PhotoImage(img)
        lbf =LabelFrame(sh_fm,text=movie[1],padx=10,pady=10)
        lbf.rowconfigure((0,1,2,3),weight=1)
        lbf.columnconfigure((0,1,2,3),weight=1)
        img = Label(lbf,image=python_image,compound=TOP)
        img.image = python_image
        img.grid(row=0,rowspan=4,columnspan=2,sticky='news',pady=20)
        Label(lbf,text='เนื้อเรื่องย่อ : '+movie[2],font='Tahoma 16',wraplength=700).grid(row=0,columnspan=2,column=2,sticky=S)
        Label(lbf,text='ประเภท : '+movie[3],font='Tahoma 16').grid(row=1,column=2,sticky=N)
        Label(lbf,text='ภาษา : '+movie[5],font='Tahoma 16').grid(row=1,column=3,sticky=N)
        Label(lbf,text='ภาพยนตร์จาก : '+movie[4],font='Tahoma 16').grid(row=1,column=2,sticky=S)
        Label(lbf,text='สามารถรับชมได้ทาง : '+movie[6],font='Tahoma 16').grid(row=1,column=3,sticky=S)



        sql = "SELECT Good, Bad from Movie where Number = ?"
        cursor.execute(sql,[movie[0]])
        score = cursor.fetchall()
        for i,item in enumerate(score):
            print('I :',i)
            print("Item :",item)
        if item[0] > item[1] :
            hrating = Label(lbf,text='แนะนำ : '+str(item[0]),font='Tahoma 30 bold',fg='green').grid(row=2,column=2,sticky=S)
            lrating = Label(lbf,text=str(item[1])+': ไม่แนะนำ',font='Tahoma 18',fg=red).grid(row=2,column=3,sticky=S)
        elif item[1] > item[0]:
            hrating = Label(lbf,text='แนะนำ : '+str(item[0]),font='Tahoma 18',fg='green').grid(row=2,column=2,sticky=S)
            lrating = Label(lbf,text=str(item[1])+': ไม่แนะนำ',font='Tahoma 30 bold',fg=red).grid(row=2,column=3,sticky=S)
        elif item[1] == item[0]:
            hrating = Label(lbf,text='แนะนำ : '+str(item[0]),font='Tahoma 18 bold',fg='green').grid(row=2,column=2,sticky=S)
            lrating = Label(lbf,text=str(item[1])+' : ไม่แนะนำ',font='Tahoma 18 bold',fg=red).grid(row=2,column=3,sticky=S)
        else:
            hrating = Label(lbf,text='แนะนำ : '+str(item[0]),font='Tahoma 18 bold',fg='green').grid(row=2,column=2,sticky=S)
            lrating = Label(lbf,text=str(item[1])+' : ไม่แนะนำ',font='Tahoma 18 bold',fg=red).grid(row=2,column=3,sticky=S)



        def good():
            sql = 'SELECT Good FROM Movie where Number = ?'
            cursor.execute(sql, [movie[0]])
            good = cursor.fetchone()
            print(cursor.fetchone())
            for i,item in enumerate(good):
                item += 1
            update_sql = " UPDATE Movie SET Good = ? WHERE Number = ?"
            cursor.execute(update_sql, (item,movie[0]))
            conn.commit()
        def bad():
            sql = 'SELECT Bad FROM Movie where Number = ?'
            cursor.execute(sql, [movie[0]])
            good = cursor.fetchone()
            print(cursor.fetchone())
            for i,item in enumerate(good):
                item += 1
            update_sql = " UPDATE Movie SET Bad = ? WHERE Number = ?"
            cursor.execute(update_sql, (item,movie[0]))
            conn.commit()
        
        Button(lbf,text='Good',width=10,bg='green',fg='white',bd=0,command=good).grid(row=3,column=2,sticky='ew')
        Button(lbf,text='Bad',width=10,bg=red,bd=0,command=bad).grid(row=3,column=3,sticky='ew')


        Button(lbf,text='Watch Later.',width=10,bg=grey,fg='white').grid(row=4,column=2,sticky='news')
        Button(lbf,text='Exit.',command=sh_fm.destroy,width=10,bg=black,fg=red).grid(row=4,column=3,sticky='news')
        
        lbf.grid(row=0,column=0,columnspan=4,rowspan=5,sticky='news',padx=10,pady=10)




        sh_fm.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

def search(keyword):
    sql = 'SELECT * FROM Movie WHERE Name = ?'
    cursor.execute(sql, [keyword])
    movie = cursor.fetchone()
    print(keyword)
    if movie != None :
        sh_fm = Frame(fm_main)
        sh_fm.rowconfigure((0,1,2,3),weight=1)
        sh_fm.columnconfigure((0,1,2,3),weight=1)
        img = Image.open(f"Image\{movie[0]}.png").resize((500, 500), Image.ANTIALIAS)#Image\2.jpg
        python_image = ImageTk.PhotoImage(img)
        lbf =LabelFrame(sh_fm,text=movie[1],padx=10,pady=10)
        lbf.rowconfigure((0,1,2,3),weight=1)
        lbf.columnconfigure((0,1,2,3),weight=1)
        img = Label(lbf,image=python_image,compound=TOP)
        img.image = python_image
        img.grid(row=0,rowspan=4,columnspan=2,sticky='news',pady=20)
        Label(lbf,text='เนื้อเรื่องย่อ : '+movie[2],font='Tahoma 16',wraplength=700).grid(row=0,columnspan=2,column=2,sticky=S)
        Label(lbf,text='ประเภท : '+movie[3],font='Tahoma 16').grid(row=1,column=2,sticky=N)
        Label(lbf,text='ภาษา : '+movie[5],font='Tahoma 16').grid(row=1,column=3,sticky=N)
        Label(lbf,text='ภาพยนตร์จาก : '+movie[4],font='Tahoma 16').grid(row=1,column=2,sticky=S)
        Label(lbf,text='สามารถรับชมได้ทาง : '+movie[6],font='Tahoma 16').grid(row=1,column=3,sticky=S)



        sql = "SELECT Good, Bad from Movie where Number = ?"
        cursor.execute(sql,[movie[0]])
        score = cursor.fetchall()
        for i,item in enumerate(score):
            print('I :',i)
            print("Item :",item)
        if item[0] > item[1] :
            hrating = Label(lbf,text='แนะนำ : '+str(item[0]),font='Tahoma 30 bold',fg='green').grid(row=2,column=2,sticky=S)
            lrating = Label(lbf,text=str(item[1])+' : ไม่แนะนำ',font='Tahoma 18',fg=red).grid(row=2,column=3,sticky=S)
        elif item[1] > item[0]:
            hrating = Label(lbf,text='แนะนำ : '+str(item[0]),font='Tahoma 18',fg='green').grid(row=2,column=2,sticky=S)
            lrating = Label(lbf,text=str(item[1])+' : ไม่แนะนำ',font='Tahoma 30 bold',fg=red).grid(row=2,column=3,sticky=S)
        elif item[1] == item[0]:
            hrating = Label(lbf,text='แนะนำ : '+str(item[0]),font='Tahoma 18 bold',fg='green').grid(row=2,column=2,sticky=S)
            lrating = Label(lbf,text=str(item[1])+' : ไม่แนะนำ',font='Tahoma 18 bold',fg=red).grid(row=2,column=3,sticky=S)
        else:
            hrating = Label(lbf,text='แนะนำ : '+str(item[0]),font='Tahoma 18 bold',fg='green').grid(row=2,column=2,sticky=S)
            lrating = Label(lbf,text=str(item[1])+' : ไม่แนะนำ',font='Tahoma 18 bold',fg=red).grid(row=2,column=3,sticky=S)



        def good():
            sql = 'SELECT Good FROM Movie where Number = ?'
            cursor.execute(sql, [movie[0]])
            good = cursor.fetchone()
            print(cursor.fetchone())
            for i,item in enumerate(good):
                item += 1
            update_sql = " UPDATE Movie SET Good = ? WHERE Number = ?"
            cursor.execute(update_sql, (item,movie[0]))
            conn.commit()
        def bad():
            sql = 'SELECT Bad FROM Movie where Number = ?'
            cursor.execute(sql, [movie[0]])
            good = cursor.fetchone()
            print(cursor.fetchone())
            for i,item in enumerate(good):
                item += 1
            update_sql = " UPDATE Movie SET Bad = ? WHERE Number = ?"
            cursor.execute(update_sql, (item,movie[0]))
            conn.commit()
        
        Button(lbf,text='Good',width=10,bg='green',fg='white',bd=0,command=good).grid(row=3,column=2,sticky='ew')
        Button(lbf,text='Bad',width=10,bg=red,bd=0,command=bad).grid(row=3,column=3,sticky='ew')


        Button(lbf,text='Watch Later.',width=10,bg=grey,fg='white',command=lambda:watchLater(movie[0])).grid(row=4,column=2,sticky='news')
        Button(lbf,text='Exit.',command=sh_fm.destroy,width=10,bg=black,fg=red).grid(row=4,column=3,sticky='news')
        
        lbf.grid(row=0,column=0,columnspan=4,rowspan=5,sticky='news',padx=10,pady=10)

        sh_fm.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')
    else:
        messagebox.showwarning("Admin: ",f"{keyword} Not Found!!")

def watchLater(name):
    global result
    wl_fm = Frame(fm_main)
    Label(wl_fm,text='รับชมภายหลัง',font=('Tahoma 18 bold')).pack(pady=10)
    sql_check = 'select * from wl where user = ?'
    cursor.execute(sql_check,(result[1]))
    check = cursor.fetchone()
    if check is None :
        sql_insert = 'insert into WL Values (?,?)'
        cursor.execute(sql_insert,(result[1],name))
        conn.commit()
        all = cursor.fetchall()
    else:
        for i,row in enumerate(check):
            print('i : ',i)
            print('row : ',row)
            if i == 1 :
                if str(name) not in str(row):
                    sql_up = 'UPDATE WL SET Number = ? WHERE user = ?'
                    cursor.execute(sql_up,((str(check[1])+'/'+str(name)),result[1]))
                    conn.commit()
                    all = cursor.fetchall()
                    print(all)
                if str(name) in str(row[1]):
                    pass
                    # messagebox.showwarning("Admin: ",f'{name} is already in Watch Later.')
            else:
                pass
    
def reviewMovie():
    Button(fm_header,text='ภาพยนตร์',bg=grey,fg='white',command=ranMovie,bd=0).grid(row=0,column=0,sticky='news')
    Button(fm_header,text='วิจารณ์ภาพยนตร์',bg=red,fg=black,command=reviewMovie,bd=0).grid(row=0,column=1,sticky='news')
    Button(fm_header,text='รายชื่อภาพยนตร์',bg=grey,fg='white',command=movieList,bd=0).grid(row=0,column=2,sticky='news')
    Button(fm_header,text='รับชมภายหลัง',bg=grey,fg='white',command=profile,bd=0).grid(row=0,column=3,sticky='news')
    rv_fm = Frame(fm_main)
    rv_fm.columnconfigure((0,1,2,3),weight=1)
    Label(rv_fm,text='วิจารณ์ภาพยนตร์',fg=grey).pack(pady=10)
    Button(rv_fm,text='เพิ่มบทวิจารณ์',bg=grey,fg=red,command=addtext).pack(anchor=W,padx=20,pady=10)

    my_canvas = Canvas(rv_fm)
    my_canvas.pack(side=LEFT, fill=BOTH, expand=4)  

    my_scrollbar = ttk.Scrollbar(rv_fm, orient=VERTICAL, command=my_canvas.yview)
    my_scrollbar.pack(side=RIGHT, fill=Y)

    my_canvas.configure(yscrollcommand=my_scrollbar.set)
    my_canvas.bind('<Configure>', lambda e: my_canvas.configure(scrollregion = my_canvas.bbox("all")))      

    second_frame = Frame(my_canvas)

    my_canvas.create_window((0,0), window=second_frame, anchor="nw")
    cursor.execute('select * from Review ')
    data = cursor.fetchall()
    for line,row in enumerate(data):
        sql = 'select * from Movie where Name = ? '
        cursor.execute(sql,[row[0]])
        data = cursor.fetchone()
        img = Image.open(f"Image\{data[0]}.png").resize((150, 150), Image.ANTIALIAS)#Image\2.jpg
        python_image = ImageTk.PhotoImage(img)
        but_img = Label(second_frame,fg=grey,image=python_image)
        but_img.image = python_image 
        but_img.grid(row=line,column=0,padx=20,pady=10)

    for line,row in enumerate(cursor.execute('select * from Review ')):
        xscroll = Scrollbar(second_frame,orient='horizontal')
        xscroll.grid(row=line,column=2,padx=20,pady=10,sticky='sew')
        mylist = Listbox(second_frame,bd = 2,height=3,width=50,xscrollcommand = xscroll.set)
        mylist.grid(row=line,column=2,padx=20,pady=10)
        for i,item in enumerate(row):
            list = ['เรื่อง : ','หัวข้อ : ','ข้อความ : ']
            mylist.insert(END,list[i]+item)

        mylist.insert(END,' ')  
        xscroll.config(command = mylist.xview)
    rv_fm.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

def addtext():
    ar_fm = Frame(fm_main)
    ar_fm.columnconfigure((0,1,2,3),weight=1)
    Label(ar_fm,text='เพิ่มรีวิว',fg=grey).grid(row=0,column=0,columnspan=4,pady=20)
    nameVar = StringVar()
    titleVar = StringVar()
    textVar = StringVar()
    Label(ar_fm,text='เรื่อง : ',font=('tahoma 16')).grid(row=1,column=0,pady=20,sticky=E)
    name = ttk.Combobox(ar_fm,font=('tahoma 16'),width=90,textvariable=nameVar,state='readonly')
    sql = 'select Number,Name FROM Movie'
    cursor.execute(sql)
    movie_name = cursor.fetchall()
    namelist = []
    for i,row in enumerate(movie_name):
        print('row',row[1])
        namelist.append(row[1])
    name['values'] = namelist
    name.grid(row=1,column=1,sticky=EW,pady=20)
    name.set('ชื่อเรื่อง')
    

    Label(ar_fm,text='หัวเรื่อง : ',font=('tahoma 16')).grid(row=2,column=0,pady=20,sticky=NE)
    title = Entry(ar_fm,font=('tahoma 16'),width=100,textvariable=titleVar).grid(row=2,column=1,sticky=W,pady=20)
    Label(ar_fm,text='ข้อความ : ',font=('tahoma 16')).grid(row=3,column=0,sticky=NE,pady=20)
    text = Text(ar_fm,font=('tahoma 16'),width=100,height=5)
    text.grid(row=3,column=1,sticky=W,pady=20)

    def insert(name,title,text):
        if not name:
                messagebox.showwarning(title='Please provide info', message='กรุณากรอกชื่อ')
                return
        if not title:
                messagebox.showwarning(title='Please provide info', message='กรุณากรอกหัวเรื่อง')
                return
        if not text:
                messagebox.showwarning(title='Please provide info', message='กรุณากรอกข้อมูล')
                return
        try:
            insert_sql = 'INSERT INTO Review (Name, Title, Data) VALUES (?, ?, ?)'
            cursor.execute(insert_sql,(name, title, text))
            conn.commit()
            print(cursor.fetchall)
            messagebox.showinfo(title='Complete', message='Thank you for commented.')
            ar_fm.destroy()
            reviewMovie()
        except Error as ex:
            messagebox.showerror(title='Error', message=ex)
    Button(ar_fm,text='ย้อนกลับ',width=20,command=ar_fm.destroy,bg=grey,fg='white').grid(row=4,column=1,sticky=W)
    Button(ar_fm,text='ยื่นยัน',width=20,command=lambda:insert(nameVar.get(),titleVar.get(),text.get(1.0 , END)),bg=red,fg=black).grid(row=4,column=1,sticky=E)



    ar_fm.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

def movieList():
    Button(fm_header,text='ภาพยนตร์',bg=grey,fg='white',command=ranMovie,bd=0).grid(row=0,column=0,sticky='news')
    Button(fm_header,text='รีวิวภาพยนตร์',bg=grey,fg='white',command=reviewMovie,bd=0).grid(row=0,column=1,sticky='news')
    Button(fm_header,text='รายชื่อภาพยนตร์',bg=red,fg=black,command=movieList,bd=0).grid(row=0,column=2,sticky='news')
    Button(fm_header,text='รับชมภายหลัง',bg=grey,fg='white',command=profile,bd=0).grid(row=0,column=3,sticky='news')

    ch_fm = Frame(fm_main)
    ch_fm.columnconfigure((0,1,2,3),weight=1)
    ch_fm.rowconfigure((1,2,3),weight=1)
    Label(ch_fm,text='รายชื่อภาพยนตร์',fg=grey).grid(row=0,columnspan=4)
    tv_fm = Frame(ch_fm)
    yscroll = Scrollbar(tv_fm,orient='vertical')
    yscroll.pack(side = RIGHT,fill=Y)
    mytree = ttk.Treeview(tv_fm, height=25, yscrollcommand = yscroll.set)
    mytree['columns'] = ('Number','Name','Type','Country','Language','On Air')
    mytree.heading("Number",text="Number") 
    mytree.heading("Name", text="Name")
    mytree.heading("Type", text="Type") 
    mytree.heading("Country", text="Country")
    mytree.heading("Language", text="Language")
    mytree.heading("On Air", text="On Air")

    mytree.column('#0',width=0,minwidth=0)
    mytree.column('Number',width=100)
    mytree.column('Name',width=300)
    mytree.column('Type',width=200)
    mytree.column('Country',width=200)
    mytree.column('Language',width=200)
    mytree.column('On Air',width=200)
    #กำหนดสี Treeview
    mytree.tag_configure('oddrow', background="white")
    mytree.tag_configure('evenrow', background="#DDDDDD")
    cursor.execute('select * from Movie ')
    movie_list = cursor.fetchall()
    data = []
    for i,row in enumerate(movie_list):
        data.append(row)
    global count
    count=0
    for i,r in enumerate(data):
        if count % 2 == 0:
            mytree.insert('', END, iid=count ,text="", values=(r[0],r[1],r[3],r[4],r[5],r[6]),tags=('evenrow',))
        else:
            mytree.insert('', END, iid=count ,text="", values=(r[0],r[1],r[3],r[4],r[5],r[6]),tags=('oddrow',))

        count += 1
    mytree.pack(fill=BOTH,expand=TRUE)
    tv_fm.grid(row=2,column=0,columnspan=4,sticky='news')

    sc_fm = Frame(ch_fm)
    sc_fm.columnconfigure((0,1,2,3),weight=1)

    search_bar = Entry(sc_fm,width=30,bd=3)
    search_bar.grid(row=0,column=0,columnspan=3,sticky='sew')
    
    def search_records():
        lookup_record = search_bar.get()
        for record in mytree.get_children():
            mytree.delete(record)
        sql = "SELECT * FROM movie WHERE Name = ?"
        cursor.execute(sql, (lookup_record))
        movie_list = cursor.fetchall()
        data = []
        for i,row in enumerate(movie_list):
            data.append(row)
        global count
        count=0
        for i,r in enumerate(data):
            if count % 2 == 0:
                mytree.insert('', END, iid=count ,text="", values=(r[0],r[1],r[3],r[4],r[5],r[6]),tags=('evenrow',))
            else:
                mytree.insert('', END, iid=count ,text="", values=(r[0],r[1],r[3],r[4],r[5],r[6]),tags=('oddrow',))

            count += 1

    sea_btn = Button(sc_fm,text='Select', font=('tahoma 18'),command=lambda:search(search_bar.get()), bg=grey,fg='white')
    sea_btn.grid(row=0,column=3,sticky='sew')

    def select_record():
        search_bar.delete(0, END)
        selected = mytree.focus()
        values = mytree.item(selected, 'values')
        search_bar.insert(0, values[1])
    

    def clicker(e):
        select_record()

    mytree.bind("<ButtonRelease-1>", clicker)

    sc_fm.grid(row=1,column=0,columnspan=4,sticky='news')

    ch_fm.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

def profile():
    global result
    Button(fm_header,text='ภาพยนตร์',bg=grey,fg='white',command=ranMovie,bd=0).grid(row=0,column=0,sticky='news')
    Button(fm_header,text='รีวิวภาพยนตร์',bg=grey,fg='white',command=reviewMovie,bd=0).grid(row=0,column=1,sticky='news')
    Button(fm_header,text='รายชื่อภาพยนตร์',bg=grey,fg='white',command=movieList,bd=0).grid(row=0,column=2,sticky='news')
    Button(fm_header,text='รับชมภายหลัง',bg=red,fg=black,command=profile,bd=0).grid(row=0,column=3,sticky='news')
    pf_fm = Frame(fm_main)
    pf_fm.columnconfigure((0,1,2,3),weight=1)
    pf_fm.rowconfigure((0,1,2,3),weight=1)
    Label(pf_fm,text='รับชมภายหลัง',fg=grey).grid(row=0,columnspan=4,sticky=N)
    sql = 'select * from login where user = ? '
    cursor.execute(sql,[result[0]])
    pro = cursor.fetchone()
    print(pro)
    Label(pf_fm,text='login by '+pro[2],font=('tahoma 20'),fg=black).grid(row=0,columnspan=4,sticky=S)

    
    Label(pf_fm,text='รับชมภายหลัง',fg=grey).grid(row=1,columnspan=4,sticky=S)
    wl_fm = Frame(pf_fm)
    wl_fm.columnconfigure((0,1,2,3),weight=1)
    my_canvas = Canvas(wl_fm)
    my_canvas.pack(side=LEFT, fill=BOTH, expand=4,padx=20,pady=20)  

    my_scrollbar = ttk.Scrollbar(wl_fm, orient=VERTICAL, command=my_canvas.yview)
    my_scrollbar.pack(side=RIGHT, fill=Y)

    my_canvas.configure(yscrollcommand=my_scrollbar.set)
    my_canvas.bind('<Configure>', lambda e: my_canvas.configure(scrollregion = my_canvas.bbox("all")))      

    second_frame = Frame(my_canvas)

    my_canvas.create_window((0,0), window=second_frame, anchor=N)
    # print('user',user)
    sql = "SELECT * FROM WL WHERE user = ?"
    cursor.execute(sql,[result[0]])
    wl = cursor.fetchone()
    print('wl : ',wl)
    if wl is not None:
        for i,item in enumerate(wl):
            if i == 1:
                wlist = item.split('/')
                for i in range(len(wlist)):
                    sql = "SELECT * FROM Movie WHERE Number = ?"
                    cursor.execute(sql,wlist[i])
                    show = cursor.fetchall()
                    print('show : ',show)
                    lbf = LabelFrame(second_frame)
                    lbf.rowconfigure((0,1,2,3),weight=1)
                    lbf.columnconfigure((0,1,2,3),weight=1)
                    img = Image.open(f"Image\{wlist[i]}.png").resize((150, 150), Image.ANTIALIAS)#Image\2.jpg
                    python_image = ImageTk.PhotoImage(img)
                    btn = Button(second_frame,fg=grey,image=python_image,command=lambda i=i:function(i))
                    btn.image = python_image 
                    btn.grid(row=i, column=0, pady=10, padx=10)
                    for line,item in enumerate(show):
                        print('line : ',line,'I : ',i,'Item : ',item)
                        Label(lbf,text='ชื่อเรื่อง : '+item[1],font='Tahoma 16').grid(row=0,column=2,columnspan=4,sticky=S,padx=10,pady=10)
                        Label(lbf,text='เนื้อเรื่องย่อ : '+item[2],font='Tahoma 16',wraplength=1000).grid(row=1,rowspan=3,columnspan=6,column=2,padx=10,pady=10)
                        Label(lbf,text='ประเภท : '+item[3],font='Tahoma 16').grid(row=4,column=2,sticky=S,padx=10,pady=10)
                        Label(lbf,text='ภาษา : '+item[5],font='Tahoma 16').grid(row=4,column=3,sticky=S,padx=10,pady=10)
                        Label(lbf,text='ภาพยนตร์จาก : '+item[4],font='Tahoma 16').grid(row=4,column=4,sticky=S,padx=10,pady=10)
                        Label(lbf,text='สามารถรับชมได้ทาง : '+item[6],font='Tahoma 16').grid(row=4,column=5,sticky=S,padx=10,pady=10)
                    lbf.grid(row=i,column=2,columnspan=2,sticky='news')
    else :
        Label(pf_fm,text='WatchLater  is empty.',font=('tahoma 18'),fg=grey).grid(row=2,columnspan=4,sticky='N')
    def function(number):
        print(number, 'clicked')
        sql = "select * from WL where user = ?"
        cursor.execute(sql,[result[1]])
        data = cursor.fetchone()
        print(data)
        for i,row in enumerate(data):
            if i == 1:
                ndata = row.split('/')
                for i,row in enumerate(ndata):
                    if number == i :
                        newI = i+1
                        print('newIIIIIIII : ',newI)
                        showMovie('number',newI)
    wl_fm.grid(row=1,column=0,columnspan=4,rowspan=3,sticky='news')

    Button(pf_fm,text='ออกจากระบบ',bg=red,command=confirmLogout).grid(row=4,column=0,columnspan=2,pady=20,padx=20)
    Button(pf_fm,text='แก้ไข',bg=red,command=edit).grid(row=4,column=3,columnspan=2,pady=20,padx=20)

    pf_fm.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

def edit():
    global result
    sh_fm = Frame(fm_main)
    sh_fm.rowconfigure((1,2,3),weight=1)
    sh_fm.columnconfigure((0,1,2),weight=1)
    Label(sh_fm,text='แก้ไข',fg=grey).grid(row=0,columnspan=4,sticky=N)
    wl_fm = Frame(sh_fm)
    wl_fm.columnconfigure((0,1,2),weight=1)
    my_canvas = Canvas(wl_fm)
    my_canvas.pack(side=LEFT, fill=BOTH, expand=4,padx=20,pady=20)  

    my_scrollbar = ttk.Scrollbar(wl_fm, orient=VERTICAL, command=my_canvas.yview)
    my_scrollbar.pack(side=RIGHT, fill=Y)

    my_canvas.configure(yscrollcommand=my_scrollbar.set)
    my_canvas.bind('<Configure>', lambda e: my_canvas.configure(scrollregion = my_canvas.bbox("all")))      

    second_frame = Frame(my_canvas)

    my_canvas.create_window((0,0), window=second_frame, anchor=N)
    sql = "SELECT * FROM WL WHERE user = ?"
    cursor.execute(sql,[result[0]])
    wl = cursor.fetchone()
    if wl is not None:
        for i,item in enumerate(wl):
            if i == 1:
                wlist = item.split('/')
                for i in range(len(wlist)):
                    sql = "SELECT * FROM Movie WHERE Number = ?"
                    cursor.execute(sql,wlist[i])
                    show = cursor.fetchall()
                    lbf = LabelFrame(second_frame)
                    lbf.rowconfigure((0,1,2,3),weight=1)
                    lbf.columnconfigure((0,1,2,3),weight=1)
                    img = Image.open(f"Image\{wlist[i]}.png").resize((300, 300), Image.ANTIALIAS)#Image\2.jpg
                    python_image = ImageTk.PhotoImage(img)
                    btn = Button(second_frame,fg=grey,image=python_image,command=lambda i=i:function(i))
                    btn.image = python_image 
                    btn.grid(row=i // 3, column=i % 3, pady=20, padx=50,sticky='news')
    wl_fm.grid(row=1,column=0,columnspan=4,rowspan=3,sticky='news')
    sh_fm.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

    def function(number):
        print(number, 'clicked')
        sql = "select * from WL where user = ?"
        cursor.execute(sql,[result[1]])
        data = cursor.fetchone()
        for i,row in enumerate(data):
            if i == 1:
                ndata = row.split('/')
                for i,row in enumerate(ndata):
                    if number == i:
                        ndata.remove(row)
                        up = ('/'.join(ndata))
                        sql_up = 'UPDATE WL SET Number = ? WHERE user = ?'
                        cursor.execute(sql_up,(up,result[1]))
                        conn.commit()
                        all = cursor.fetchall()
                        messagebox.showinfo('Admid : ','Delete is Completed.')

def showMovie(name,e):
    print('name :',name)
    print(type(e),e)

    if name == 'type':
        sql = 'SELECT * FROM  Movie WHERE Type = ?'
    elif name == 'language':
        sql = 'SELECT * FROM  Movie WHERE Language = ?'
    elif name == 'name':
        sql = 'SELECT * FROM Movie WHERE Name = ?'
    elif name == 'number':
        sql = 'SELECT * FROM Movie WHERE Number = ?'
    cursor.execute(sql, [e])
    data = cursor.fetchall()
    if len(data) > 1 :
        print('len(data) > 1')
        sh_fm = Frame(fm_main)
        sh_fm.rowconfigure((1,2,3),weight=1)
        sh_fm.columnconfigure((0,1,2,3),weight=1)
        Label(sh_fm,text='ผลการค้นหา',fg=grey).grid(row=0,columnspan=4,sticky=N)
        sc_fm = Frame(sh_fm)
        my_canvas = Canvas(sc_fm)
        my_canvas.pack(side=LEFT, fill=BOTH, expand=4,padx=20,pady=20)  

        my_scrollbar = ttk.Scrollbar(sc_fm, orient=VERTICAL, command=my_canvas.yview)
        my_scrollbar.pack(side=RIGHT, fill=Y)

        my_canvas.configure(yscrollcommand=my_scrollbar.set)
        my_canvas.bind('<Configure>', lambda e: my_canvas.configure(scrollregion = my_canvas.bbox("all")))      

        second_frame = Frame(my_canvas)
        my_canvas.create_window((0,0), window=second_frame, anchor='n')

        for i,row in enumerate(data):
            # print('I :',i,'Row :',row)
            lbf = LabelFrame(second_frame,text=row[1])
            lbf.rowconfigure((0,1,2,3),weight=1)
            lbf.columnconfigure((0,1,2,3),weight=1)
            img = Image.open(f"Image\{row[0]}.png").resize((250, 250), Image.ANTIALIAS)#Image\2.jpg
            python_image = ImageTk.PhotoImage(img)
            btn = Button(second_frame,image=python_image,command=lambda i=i :function(i))
            btn.image = python_image
            btn.grid(row=i, column=0, pady=10, padx=10)
            Label(lbf,text='เนื้อเรื่องย่อ : '+row[2],font='Tahoma 16',wraplength=700).grid(row=1,rowspan=3,columnspan=6,column=2,sticky=N,padx=10,pady=10)
            Label(lbf,text='ประเภท : '+row[3],font='Tahoma 16').grid(row=4,column=2,sticky=S,padx=10,pady=10)
            Label(lbf,text='ภาษา : '+row[5],font='Tahoma 16').grid(row=4,column=3,sticky=S,padx=10,pady=10)
            Label(lbf,text='ภาพยนตร์จาก : '+row[4],font='Tahoma 16').grid(row=4,column=4,sticky=S,padx=10,pady=10)
            Label(lbf,text='สามารถรับชมได้ทาง : '+row[6],font='Tahoma 16').grid(row=4,column=5,sticky=S,padx=10,pady=10)
            lbf.grid(row=i,column=2,columnspan=4,sticky='news')
        sc_fm.grid(row=1,column=0,columnspan=4,rowspan=4,sticky='news')
        sh_fm.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

        def function(number):
            cursor.execute(sql, [e])
            data = cursor.fetchall()
            for i,row in enumerate(data):
                if number == i:
                    ndata = data[i]
                    showMovie('name',ndata[1])
            
            
    elif len(data) == 1 :
        for i,row in enumerate(data):
            sh_fm = Frame(fm_main)
            sh_fm.rowconfigure((0,1,2,3),weight=1)
            sh_fm.columnconfigure((0,1,2,3),weight=1)
            img = Image.open(f"Image\{row[0]}.png").resize((500, 500), Image.ANTIALIAS)#Image\2.jpg
            python_image = ImageTk.PhotoImage(img)
            lbf =LabelFrame(sh_fm,text=row[1],padx=10,pady=10)
            lbf.rowconfigure((0,1,2,3),weight=1)
            lbf.columnconfigure((0,1,2,3),weight=1)
            img = Label(lbf,image=python_image,compound=TOP)
            img.image = python_image
            img.grid(row=0,rowspan=4,columnspan=2,sticky='news',pady=20)
            Label(lbf,text='เนื้อเรื่องย่อ : '+row[2],font='Tahoma 16',wraplength=700).grid(row=0,columnspan=2,column=2,sticky=N)
            Label(lbf,text='ประเภท : '+row[3],font='Tahoma 16').grid(row=1,column=2,sticky=N)
            Label(lbf,text='ภาษา : '+row[5],font='Tahoma 16').grid(row=1,column=3,sticky=N)
            Label(lbf,text='ภาพยนตร์จาก : '+row[4],font='Tahoma 16').grid(row=1,column=2,sticky=S)
            Label(lbf,text='สามารถรับชมได้ทาง : '+row[6],font='Tahoma 16').grid(row=1,column=3,sticky=S)

            sql = "SELECT Good, Bad from Movie where Number = ?"
            cursor.execute(sql,[row[0]])
            score = cursor.fetchall()
            for i,item in enumerate(score):
                print('I :',i)
                print("Item :",item)
            if item[0] > item[1] :
                hrating = Label(lbf,text='แนะนำ : '+str(item[0]),font='Tahoma 30 bold',fg='green').grid(row=2,column=2,sticky=S)
                lrating = Label(lbf,text=str(item[1])+': ไม่แนะนำ',font='Tahoma 18',fg=red).grid(row=2,column=3,sticky=S)
            elif item[1] > item[0]:
                hrating = Label(lbf,text='แนะนำ : '+str(item[0]),font='Tahoma 18',fg='green').grid(row=2,column=2,sticky=S)
                lrating = Label(lbf,text=str(item[1])+': ไม่แนะนำ',font='Tahoma 30 bold',fg=red).grid(row=2,column=3,sticky=S)
            elif item[1] == item[0]:
                hrating = Label(lbf,text='แนะนำ : '+str(item[0]),font='Tahoma 18 bold',fg='green').grid(row=2,column=2,sticky=S)
                lrating = Label(lbf,text=str(item[1])+' : ไม่แนะนำ',font='Tahoma 18 bold',fg=red).grid(row=2,column=3,sticky=S)
            else:
                hrating = Label(lbf,text='แนะนำ : '+str(item[0]),font='Tahoma 18 bold',fg='green').grid(row=2,column=2,sticky=S)
                lrating = Label(lbf,text=str(item[1])+' : ไม่แนะนำ',font='Tahoma 18 bold',fg=red).grid(row=2,column=3,sticky=S)

            Button(lbf,text='Good',width=10,bg='green',fg='white',bd=0,command=lambda:good(row[0])).grid(row=3,column=2,sticky='ew')
            Button(lbf,text='Bad',width=10,bg=red,bd=0,command=lambda:bad(row[0])).grid(row=3,column=3,sticky='ew')


            Button(lbf,text='Watch Later.',width=10,bg=grey,fg='white').grid(row=4,column=2,sticky='news')
            Button(lbf,text='Exit.',command=sh_fm.destroy,width=10,bg=black,fg=red).grid(row=4,column=3,sticky='news')
            
            lbf.grid(row=0,column=0,columnspan=4,rowspan=5,sticky='news',padx=10,pady=10)
            sh_fm.grid(row=0,column=0,columnspan=4,rowspan=4,sticky='news')

def good(e):
    sql = 'SELECT Good FROM Movie where Number = ?'
    cursor.execute(sql, [e])
    good = cursor.fetchone()
    print(cursor.fetchone())
    for i,item in enumerate(good):
        item += 1
        update_sql = " UPDATE Movie SET Good = ? WHERE Number = ?"
        cursor.execute(update_sql, [item,e])
        conn.commit()    

def bad(e):
    sql = 'SELECT Bad FROM Movie where Number = ?'
    cursor.execute(sql, [e])
    good = cursor.fetchone()
    print(cursor.fetchone())
    for i,item in enumerate(good):
        item += 1
        update_sql = " UPDATE Movie SET Bad = ? WHERE Number = ?"
        cursor.execute(update_sql, (item,e))
        conn.commit()

def confirmLogout():   
    confirm = messagebox.askokcancel('Confirm','Are you sure you want to logout ?')
    print(confirm)
    if confirm == True:
        loginLayout()
    print('Profile')


conn,cursor = createconnection()
root = mainWindows()
regisframe = Frame(root)
radiospy = IntVar()


logo = Image.open('Image\image-removebg-preview.png').resize((250,250))
logopic = ImageTk.PhotoImage(logo)

fm_header, fm_main = initLayout(root)
loginLayout()



root.mainloop()
cursor.close()
conn.close()
